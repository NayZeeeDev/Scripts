--[[
    NAYZEEE MULTIJOB - Client Main
    Version: 1.0.0
    Discord: discord.gg/nayzeeedev
]]

if not NAYZEEE_LOCK_OK then return end

local isUIOpen = false
local isAdminOpen = false
local PlayerJob = nil
local PlayerGrade = 0
local PlayerGroup = 'user'
local PlayerJobs = {}
local PlayerFavorites = {}
local PlayerStats = {}
local PlayerSchedules = {}
local PlayerShifts = {}

local isOnDuty = false
local dutyStartTime = 0
local lastActivity = 0
local lastJobSwitch = 0

-- ═══════════════════════════════════════════════════════════════════════════
-- INITIALIZATION
-- ═══════════════════════════════════════════════════════════════════════════

CreateThread(function()
    Wait(1000)
    
    local fw = Shared.GetFramework()
    local FW = Shared.GetFrameworkObject()
    
    if fw == 'esx' then
        while not FW.IsPlayerLoaded() do Wait(100) end
        local playerData = FW.GetPlayerData()
        PlayerJob = playerData.job.name
        PlayerGrade = playerData.job.grade
        PlayerGroup = playerData.group or 'user'
        
        RegisterNetEvent('esx:setJob')
        AddEventHandler('esx:setJob', function(job)
            local oldJob = PlayerJob
            PlayerJob = job.name
            PlayerGrade = job.grade
            Shared.Debug('Job changed from', oldJob, 'to', PlayerJob)
            TriggerServerEvent('nayzeee-multijob:checkNewJob', oldJob, PlayerJob, PlayerGrade)
            
            if PlayerJob == 'unemployed' and not isOnDuty then
                Wait(500)
                isOnDuty = true
                dutyStartTime = GetGameTimer()
                lastActivity = GetGameTimer()
                TriggerServerEvent('nayzeee-multijob:clockIn', PlayerJob)
                SendNUIMessage({ action = 'updateDutyStatus', data = { isOnDuty = true, isUnemployed = true } })
                Shared.Debug('Auto clocked in - switched to unemployed')
            end
        end)
        
        RegisterNetEvent('esx:setGroup')
        AddEventHandler('esx:setGroup', function(group)
            PlayerGroup = group
        end)
        
    elseif fw == 'qbcore' or fw == 'qbox' then
        while not FW.Functions.GetPlayerData().citizenid do Wait(100) end
        local playerData = FW.Functions.GetPlayerData()
        PlayerJob = playerData.job.name
        PlayerGrade = playerData.job.grade.level
        
        lib.callback('nayzeee-multijob:getPlayerGroup', false, function(group)
            PlayerGroup = group or 'user'
        end)
        
        RegisterNetEvent('QBCore:Client:OnJobUpdate')
        AddEventHandler('QBCore:Client:OnJobUpdate', function(job)
            local oldJob = PlayerJob
            PlayerJob = job.name
            PlayerGrade = job.grade.level
            TriggerServerEvent('nayzeee-multijob:checkNewJob', oldJob, PlayerJob, PlayerGrade)
            
            if PlayerJob == 'unemployed' and not isOnDuty then
                Wait(500)
                isOnDuty = true
                dutyStartTime = GetGameTimer()
                lastActivity = GetGameTimer()
                TriggerServerEvent('nayzeee-multijob:clockIn', PlayerJob)
                SendNUIMessage({ action = 'updateDutyStatus', data = { isOnDuty = true, isUnemployed = true } })
                Shared.Debug('Auto clocked in - switched to unemployed')
            end
        end)
    end
    
    LoadPlayerData()
    
    if Config.DutyTracking and Config.DutyTracking.enabled then
        StartDutyTracking()
    end
    
    Wait(2000)
    if PlayerJob == 'unemployed' then
        if not isOnDuty then
            isOnDuty = true
            dutyStartTime = GetGameTimer()
            lastActivity = GetGameTimer()
            TriggerServerEvent('nayzeee-multijob:clockIn', PlayerJob)
            Shared.Debug('Auto clocked in unemployed player')
        end
    end
end)

function LoadPlayerData()
    lib.callback('nayzeee-multijob:getPlayerData', false, function(data)
        if data then
            PlayerJobs = data.jobs or {}
            PlayerFavorites = data.favorites or {}
            PlayerStats = data.stats or {}
            PlayerSchedules = data.schedules or {}
            PlayerShifts = data.shifts or {}
            Shared.Debug('Loaded player data:', #PlayerJobs, 'jobs,', #PlayerShifts, 'shifts')
            
            -- Live-refresh NUI if menu is open
            if isUIOpen then
                SendNUIMessage({
                    action = 'refreshData',
                    data = {
                        currentJob = PlayerJob,
                        currentGrade = PlayerGrade,
                        jobs = PlayerJobs,
                        favorites = PlayerFavorites,
                        stats = PlayerStats,
                        categories = Config.Categories,
                        isOnDuty = isOnDuty,
                        isUnemployed = PlayerJob == 'unemployed',
                        dutyTime = isOnDuty and (GetGameTimer() - dutyStartTime) / 1000 or 0,
                        maxJobs = Config.MaxJobs,
                        locale = Config.Locale,
                        schedules = PlayerSchedules,
                        shifts = PlayerShifts,
                    }
                })
            end
        end
    end)
end

-- ═══════════════════════════════════════════════════════════════════════════
-- UI FUNCTIONS
-- ═══════════════════════════════════════════════════════════════════════════

function OpenJobMenu()
    if isUIOpen then return end
    isUIOpen = true
    
    lib.callback('nayzeee-multijob:getPlayerData', false, function(data)
        if data then
            PlayerJobs = data.jobs or {}
            PlayerFavorites = data.favorites or {}
            PlayerStats = data.stats or {}
            PlayerSchedules = data.schedules or {}
            PlayerShifts = data.shifts or {}
        end
        
        SetNuiFocus(true, true)
        SendNUIMessage({
            action = 'openMenu',
            data = {
                currentJob = PlayerJob,
                currentGrade = PlayerGrade,
                jobs = PlayerJobs,
                favorites = PlayerFavorites,
                stats = PlayerStats,
                categories = Config.Categories,
                isOnDuty = isOnDuty,
                isUnemployed = PlayerJob == 'unemployed',
                dutyTime = isOnDuty and (GetGameTimer() - dutyStartTime) / 1000 or 0,
                maxJobs = Config.MaxJobs,
                locale = Config.Locale,
                leaderboards = Config.Leaderboards and Config.Leaderboards.enabled,
                scheduleEnabled = Config.Schedule and Config.Schedule.enabled,
                schedules = PlayerSchedules,
                shifts = PlayerShifts,
                ui = Config.UI,
                version = GetResourceMetadata(GetCurrentResourceName(), 'version', 0),
                playerName = GetPlayerName(PlayerId()),
            }
        })
    end)
end

function OpenAdminPanel()
    if not CanAccessAdmin() then
        Shared.Notify('Error', Config.Locale['admin_no_permission'], 'error')
        return
    end
    if isAdminOpen then return end
    isAdminOpen = true
    
    lib.callback('nayzeee-multijob:getAdminData', false, function(data)
        if not data then
            isAdminOpen = false
            return
        end
        SetNuiFocus(true, true)
        data.ui = Config.UI
        data.version = GetResourceMetadata(GetCurrentResourceName(), 'version', 0)
        SendNUIMessage({
            action = 'openAdmin',
            data = data
        })
    end)
end

function CloseUI()
    isUIOpen = false
    isAdminOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end

function CanAccessAdmin()
    for _, group in ipairs(Config.AdminGroups) do
        if string.lower(PlayerGroup) == string.lower(group) then return true end
    end
    return false
end

-- ═══════════════════════════════════════════════════════════════════════════
-- DUTY TRACKING
-- ═══════════════════════════════════════════════════════════════════════════

function StartDutyTracking()
    -- Inactivity checker
    CreateThread(function()
        while true do
            Wait(10000)
            
            if isOnDuty and Config.DutyTracking.autoClockOut and Config.DutyTracking.autoClockOut.enabled then
                local elapsed = (GetGameTimer() - lastActivity) / 60000
                local warn = Config.DutyTracking.autoClockOut.warningMinutes or 25
                local max = Config.DutyTracking.autoClockOut.inactivityMinutes or 30
                
                if elapsed >= max then
                    ClockOut(true)
                elseif elapsed >= warn then
                    Shared.Notify('Warning', string.format(Config.Locale['inactivity_warning'], math.ceil(max - elapsed)), 'warning')
                end
            end
        end
    end)
    
    -- Periodic save
    CreateThread(function()
        while true do
            Wait((Config.DutyTracking.saveInterval or 60) * 1000)
            
            if isOnDuty then
                local dutySeconds = (GetGameTimer() - dutyStartTime) / 1000
                TriggerServerEvent('nayzeee-multijob:saveDutyTime', PlayerJob, dutySeconds)
            end
        end
    end)
    
    -- Activity tracker
    CreateThread(function()
        while true do
            Wait(5000)
            
            if isOnDuty then
                local ped = PlayerPedId()
                if IsPedWalking(ped) or IsPedRunning(ped) or IsPedInAnyVehicle(ped, false) or IsControlPressed(0, 24) or IsControlPressed(0, 25) then
                    lastActivity = GetGameTimer()
                end
            end
        end
    end)
    
    -- UI timer updater
    CreateThread(function()
        while true do
            Wait(1000)
            
            if isOnDuty and isUIOpen then
                local dutySeconds = (GetGameTimer() - dutyStartTime) / 1000
                SendNUIMessage({ 
                    action = 'updateDutyTime', 
                    time = dutySeconds 
                })
            end
        end
    end)
end

function ClockIn()
    if isOnDuty then 
        Shared.Debug('Already on duty')
        return 
    end
    
    if PlayerJob == 'unemployed' then
        Shared.Notify('Duty', 'You are always on duty as unemployed', 'error')
        return
    end
    
    isOnDuty = true
    dutyStartTime = GetGameTimer()
    lastActivity = GetGameTimer()
    
    TriggerServerEvent('nayzeee-multijob:clockIn', PlayerJob)
    Shared.Notify('Duty', Config.Locale['clocked_in'], 'success')
    
    SendNUIMessage({ 
        action = 'updateDutyStatus', 
        data = { isOnDuty = true }
    })
    
    Shared.Debug('Clocked in to', PlayerJob)
end

function ClockOut(auto, silent)
    if not isOnDuty then 
        Shared.Debug('Not on duty')
        return 
    end
    
    if PlayerJob == 'unemployed' and not auto and not silent then
        Shared.Notify('Duty', 'You cannot clock out while unemployed', 'error')
        return
    end
    
    local dutySeconds = (GetGameTimer() - dutyStartTime) / 1000
    isOnDuty = false
    
    TriggerServerEvent('nayzeee-multijob:clockOut', PlayerJob, dutySeconds)
    
    local timeStr = Shared.FormatTime(math.floor(dutySeconds))
    if not silent then
        if auto then
            Shared.Notify('Duty', Config.Locale['auto_clock_out'], 'warning')
        else
            Shared.Notify('Duty', string.format(Config.Locale['clocked_out'], timeStr), 'info')
        end
    end
    
    SendNUIMessage({ 
        action = 'updateDutyStatus', 
        data = { isOnDuty = false }
    })
    
    dutyStartTime = 0
    
    Shared.Debug('Clocked out after', timeStr)
end

-- ═══════════════════════════════════════════════════════════════════════════
-- JOB SWITCHING
-- ═══════════════════════════════════════════════════════════════════════════

function SwitchJob(jobName, grade)
    Shared.Debug('SwitchJob called:', jobName, grade)
    
    if Config.Cooldowns and Config.Cooldowns.enabled and not Shared.IsCooldownExempt(jobName) then
        local cooldown = Shared.GetJobCooldown(jobName)
        local elapsed = (GetGameTimer() - lastJobSwitch) / 1000
        if elapsed < cooldown then
            Shared.Notify('Cooldown', string.format(Config.Locale['cooldown_active'], Shared.FormatTime(math.ceil(cooldown - elapsed))), 'error')
            return
        end
    end
    
    if isOnDuty then 
        ClockOut(false, true)
    end
    
    TriggerServerEvent('nayzeee-multijob:switchJob', jobName, grade or 0)
    lastJobSwitch = GetGameTimer()
end

-- ═══════════════════════════════════════════════════════════════════════════
-- NUI CALLBACKS
-- ═══════════════════════════════════════════════════════════════════════════

RegisterNUICallback('close', function(_, cb) 
    CloseUI() 
    cb('ok') 
end)

RegisterNUICallback('switchJob', function(data, cb) 
    Shared.Debug('NUI switchJob:', data.job, data.grade)
    SwitchJob(data.job, data.grade) 
    cb('ok') 
end)

RegisterNUICallback('removeJob', function(data, cb)
    if Shared.IsNonRemovable(data.job) then 
        Shared.Notify('Error', 'This job cannot be removed', 'error')
        cb('error') 
        return 
    end
    TriggerServerEvent('nayzeee-multijob:removeJob', data.job)
    cb('ok')
end)

RegisterNUICallback('quitJob', function(data, cb)
    if not data.job or data.job == 'unemployed' then
        Shared.Notify('Error', 'You cannot quit this job', 'error')
        cb('error')
        return
    end
    if isOnDuty then
        ClockOut(false)
    end
    TriggerServerEvent('nayzeee-multijob:quitJob', data.job)
    cb('ok')
end)

RegisterNUICallback('clockIn', function(_, cb) 
    Shared.Debug('NUI clockIn callback')
    ClockIn() 
    cb('ok') 
end)

RegisterNUICallback('clockOut', function(_, cb) 
    Shared.Debug('NUI clockOut callback')
    ClockOut(false) 
    cb('ok') 
end)

RegisterNUICallback('getLeaderboards', function(_, cb)
    lib.callback('nayzeee-multijob:getLeaderboards', false, function(data) 
        cb(data or {}) 
    end)
end)

RegisterNUICallback('saveSchedule', function(data, cb) 
    TriggerServerEvent('nayzeee-multijob:saveSchedule', data) 
    cb('ok') 
end)

RegisterNUICallback('deleteSchedule', function(data, cb) 
    TriggerServerEvent('nayzeee-multijob:deleteSchedule', data.id) 
    cb('ok') 
end)

RegisterNUICallback('adminGetPlayer', function(data, cb)
    lib.callback('nayzeee-multijob:adminGetPlayer', false, function(pdata) 
        cb(pdata or {}) 
    end, data.id)
end)

RegisterNUICallback('adminAddJob', function(data, cb) 
    TriggerServerEvent('nayzeee-multijob:adminAddJob', data.playerId, data.job, data.grade) 
    cb('ok') 
end)

RegisterNUICallback('adminRemoveJob', function(data, cb) 
    TriggerServerEvent('nayzeee-multijob:adminRemoveJob', data.playerId, data.job) 
    cb('ok') 
end)

RegisterNUICallback('adminBulkAction', function(data, cb) 
    TriggerServerEvent('nayzeee-multijob:adminBulkAction', data.action, data.playerIds, data.job, data.grade) 
    cb('ok') 
end)

-- ═══════════════════════════════════════════════════════════════════════════
-- COMMANDS & KEYBINDS
-- ═══════════════════════════════════════════════════════════════════════════

RegisterCommand(Config.Command, function() 
    OpenJobMenu() 
end, false)

RegisterCommand(Config.AdminCommand, function() 
    OpenAdminPanel() 
end, false)

if Config.Keybind then 
    RegisterKeyMapping(Config.Command, 'Open Job Menu', 'keyboard', Config.Keybind) 
end

-- ═══════════════════════════════════════════════════════════════════════════
-- NET EVENTS
-- ═══════════════════════════════════════════════════════════════════════════

RegisterNetEvent('nayzeee-multijob:jobSwitched', function(jobName, label) 
    PlayerJob = jobName
    Shared.Debug('Job switched to', jobName)
    Shared.Notify('Job', string.format(Config.Locale['job_switched'], label), 'success') 
    LoadPlayerData()
    
    if isUIOpen then
        SendNUIMessage({
            action = 'jobSwitched',
            data = {
                currentJob = jobName,
                currentGrade = PlayerGrade
            }
        })
    end
end)

RegisterNetEvent('nayzeee-multijob:jobAdded', function() 
    Shared.Notify('Job', Config.Locale['job_added'], 'success') 
    LoadPlayerData() 
end)

RegisterNetEvent('nayzeee-multijob:jobRemoved', function() 
    Shared.Notify('Job', Config.Locale['job_removed'], 'info') 
    LoadPlayerData() 
end)

RegisterNetEvent('nayzeee-multijob:scheduleReminder', function(jobLabel, minutes)
    Shared.Notify('Schedule', string.format(Config.Locale['schedule_reminder'], jobLabel, minutes), 'info')
end)

RegisterNetEvent('nayzeee-multijob:scheduledSwitch', function(jobName, grade)
    SwitchJob(jobName, grade)
end)

RegisterNetEvent('nayzeee-multijob:shiftEnded', function(data)
    Shared.Debug('Shift ended:', data.job, data.duration, data.earnings)
    
    LoadPlayerData()
    
    if isUIOpen then
        Wait(500)
        lib.callback('nayzeee-multijob:getPlayerData', false, function(playerData)
            if playerData then
                SendNUIMessage({
                    action = 'shiftsUpdated',
                    data = {
                        shifts = playerData.shifts or {},
                        stats = playerData.stats or {}
                    }
                })
            end
        end)
    end
end)

-- ═══════════════════════════════════════════════════════════════════════════
-- EXPORTS
-- ═══════════════════════════════════════════════════════════════════════════

exports('GetPlayerJobs', function() return PlayerJobs end)
exports('GetCurrentJob', function() return PlayerJob, PlayerGrade end)
exports('IsOnDuty', function() return isOnDuty end)
exports('GetDutyTime', function() return isOnDuty and (GetGameTimer() - dutyStartTime) / 1000 or 0 end)
exports('ClockIn', ClockIn)
exports('ClockOut', function() ClockOut(false) end)
exports('OpenMenu', OpenJobMenu)
