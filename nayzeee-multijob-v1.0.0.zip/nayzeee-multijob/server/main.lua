--[[
    NAYZEEE MULTIJOB - Server Main
    Version: 1.0.0
    Discord: discord.gg/nayzeeedev
]]

if not NAYZEEE_LOCK_OK then return end

-- oxmysql returns TINYINT(1) as a number on some builds and a boolean on
-- others. Treat both as truthy so the UI shows the right actions either way.
local function IsTrue(v)
    return v == 1 or v == true or v == '1'
end

local JobInfo = {}
local DutySessions = {}

-- ═══════════════════════════════════════════════════════════════════════════
-- INITIALIZATION
-- ═══════════════════════════════════════════════════════════════════════════

CreateThread(function()
    Wait(1000)

    print('^2')
    print('    ███╗   ██╗ █████╗ ██╗   ██╗███████╗███████╗███████╗███████╗')
    print('    ████╗  ██║██╔══██╗╚██╗ ██╔╝╚══███╔╝██╔════╝██╔════╝██╔════╝')
    print('    ██╔██╗ ██║███████║ ╚████╔╝   ███╔╝ █████╗  █████╗  █████╗  ')
    print('    ██║╚██╗██║██╔══██║  ╚██╔╝   ███╔╝  ██╔══╝  ██╔══╝  ██╔══╝  ')
    print('    ██║ ╚████║██║  ██║   ██║   ███████╗███████╗███████╗███████╗')
    print('    ╚═╝  ╚═══╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚══════╝╚══════╝╚══════╝')
    print('^7')
    local version = GetResourceMetadata(GetCurrentResourceName(), 'version', 0) or '1.0.0'
    print(('^5    NAYZEEE MULTIJOB ^7| ^3v%s ^7| ^5discord.gg/nayzeeedev^7'):format(version))
    print('')
    
    -- Create tables
    MySQL.query([[
        CREATE TABLE IF NOT EXISTS `nayzeee_multijob` (
            `identifier` VARCHAR(60) NOT NULL,
            `job` VARCHAR(50) NOT NULL,
            `grade` INT DEFAULT 0,
            `removeable` TINYINT(1) DEFAULT 1,
            `favorite` TINYINT(1) DEFAULT 0,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`identifier`, `job`)
        )
    ]])
    
    MySQL.query([[
        CREATE TABLE IF NOT EXISTS `nayzeee_multijob_stats` (
            `identifier` VARCHAR(60) NOT NULL,
            `job` VARCHAR(50) NOT NULL,
            `total_hours` FLOAT DEFAULT 0,
            `total_earnings` INT DEFAULT 0,
            `sessions` INT DEFAULT 0,
            `last_clocked` TIMESTAMP NULL,
            PRIMARY KEY (`identifier`, `job`)
        )
    ]])
    
    MySQL.query([[
        CREATE TABLE IF NOT EXISTS `nayzeee_multijob_logs` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `identifier` VARCHAR(60) NOT NULL,
            `player_name` VARCHAR(100),
            `action` VARCHAR(50) NOT NULL,
            `job` VARCHAR(50),
            `details` TEXT,
            `admin_id` VARCHAR(60),
            `admin_name` VARCHAR(100),
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ]])
    
    MySQL.query([[
        CREATE TABLE IF NOT EXISTS `nayzeee_multijob_shifts` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `identifier` VARCHAR(60) NOT NULL,
            `job` VARCHAR(50) NOT NULL,
            `clock_in` TIMESTAMP NOT NULL,
            `clock_out` TIMESTAMP NULL,
            `duration_seconds` INT DEFAULT 0,
            `earnings` INT DEFAULT 0,
            INDEX `idx_identifier` (`identifier`),
            INDEX `idx_job` (`job`)
        )
    ]])
    
    MySQL.query([[
        CREATE TABLE IF NOT EXISTS `nayzeee_multijob_schedules` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `identifier` VARCHAR(60) NOT NULL,
            `job` VARCHAR(50) NOT NULL,
            `grade` INT DEFAULT 0,
            `hour` INT NOT NULL,
            `minute` INT NOT NULL,
            `days` VARCHAR(20) NOT NULL,
            `enabled` TINYINT(1) DEFAULT 1,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ]])
    
    -- Load job info from ESX
    Wait(500)
    local fw = Shared.GetFramework()
    if fw == 'esx' then
        local jobs = MySQL.query.await('SELECT * FROM jobs') or {}
        for _, job in ipairs(jobs) do
            JobInfo[job.name] = { label = job.label, grades = {} }
            local grades = MySQL.query.await('SELECT * FROM job_grades WHERE job_name = ?', { job.name }) or {}
            for _, g in ipairs(grades) do
                JobInfo[job.name].grades[g.grade] = g
            end
        end
        print('^2[nayzeee-multijob]^7 Loaded ^5' .. #jobs .. '^7 jobs from ESX database')
    elseif fw == 'qbcore' or fw == 'qbox' then
        local FW = Shared.GetFrameworkObject()
        if FW and FW.Shared and FW.Shared.Jobs then
            local count = 0
            for name, job in pairs(FW.Shared.Jobs) do
                JobInfo[name] = { label = job.label, grades = job.grades }
                count = count + 1
            end
            print('^2[nayzeee-multijob]^7 Loaded ^5' .. count .. '^7 jobs from QBCore')
        end
    end
    
    if Config.Schedule and Config.Schedule.enabled then
        StartScheduleChecker()
    end
end)

-- ═══════════════════════════════════════════════════════════════════════════
-- SCHEDULE CHECKER
-- ═══════════════════════════════════════════════════════════════════════════

function StartScheduleChecker()
    CreateThread(function()
        while true do
            Wait(60000)
            
            local currentTime = os.date('*t')
            local currentMinutes = currentTime.hour * 60 + currentTime.min
            local currentDay = currentTime.wday
            
            local schedules = MySQL.query.await('SELECT * FROM nayzeee_multijob_schedules WHERE enabled = 1') or {}
            
            for _, schedule in ipairs(schedules) do
                local scheduleMinutes = (schedule.hour or 0) * 60 + (schedule.minute or 0)
                local diff = scheduleMinutes - currentMinutes
                local dayMatch = string.find(schedule.days or '', tostring(currentDay))
                
                if dayMatch then
                    local source = GetPlayerByIdentifier(schedule.identifier)
                    if source then
                        local jobData = JobInfo[schedule.job]
                        local jobLabel = jobData and jobData.label or schedule.job
                        
                        if diff == (Config.Schedule.notifyBefore or 5) then
                            TriggerClientEvent('nayzeee-multijob:scheduleReminder', source, jobLabel, diff)
                        elseif diff == 0 then
                            TriggerClientEvent('nayzeee-multijob:scheduledSwitch', source, schedule.job, schedule.grade or 0)
                        end
                    end
                end
            end
        end
    end)
end

function GetPlayerByIdentifier(identifier)
    local fw = Shared.GetFramework()
    local FW = Shared.GetFrameworkObject()
    
    if fw == 'esx' then
        local xPlayer = FW.GetPlayerFromIdentifier(identifier)
        return xPlayer and xPlayer.source
    elseif fw == 'qbcore' or fw == 'qbox' then
        local players = FW.Functions.GetQBPlayers()
        for _, player in pairs(players or {}) do
            if player.PlayerData.citizenid == identifier then
                return player.PlayerData.source
            end
        end
    end
    return nil
end

-- ═══════════════════════════════════════════════════════════════════════════
-- HELPER FUNCTIONS
-- ═══════════════════════════════════════════════════════════════════════════

local function GetIdentifier(source)
    local fw = Shared.GetFramework()
    local FW = Shared.GetFrameworkObject()
    
    if fw == 'esx' then
        local xPlayer = FW.GetPlayerFromId(source)
        return xPlayer and xPlayer.identifier
    elseif fw == 'qbcore' or fw == 'qbox' then
        local player = FW.Functions.GetPlayer(source)
        return player and player.PlayerData.citizenid
    end
    return nil
end

local function GetPlayerNameServer(source)
    return GetPlayerName(source) or 'Unknown'
end

-- Get character name (firstname + lastname) for a given identifier
local function GetCharacterName(identifier)
    local fw = Shared.GetFramework()
    
    if fw == 'esx' then
        local result = MySQL.query.await('SELECT firstname, lastname FROM users WHERE identifier = ? LIMIT 1', { identifier })
        if result and result[1] then
            local first = result[1].firstname or ''
            local last = result[1].lastname or ''
            if first ~= '' or last ~= '' then
                return first .. ' ' .. last
            end
        end
    elseif fw == 'qbcore' or fw == 'qbox' then
        local result = MySQL.query.await('SELECT charinfo FROM players WHERE citizenid = ? LIMIT 1', { identifier })
        if result and result[1] and result[1].charinfo then
            local charinfo = result[1].charinfo
            if type(charinfo) == 'string' then
                charinfo = json.decode(charinfo) or {}
            end
            local first = charinfo.firstname or ''
            local last = charinfo.lastname or ''
            if first ~= '' or last ~= '' then
                return first .. ' ' .. last
            end
        end
    end
    
    return identifier:sub(1, 20)
end

local function SetPlayerJob(source, job, grade)
    local fw = Shared.GetFramework()
    local FW = Shared.GetFrameworkObject()
    
    print('^3[nayzeee-multijob]^7 SetPlayerJob: source=' .. tostring(source) .. ', job=' .. tostring(job) .. ', grade=' .. tostring(grade))
    
    if fw == 'esx' then
        local xPlayer = FW.GetPlayerFromId(source)
        if xPlayer then 
            if not JobInfo[job] then
                print('^1[nayzeee-multijob]^7 ERROR: Job "' .. tostring(job) .. '" does not exist in ESX jobs table!')
                return false
            end
            
            xPlayer.setJob(job, grade)
            print('^2[nayzeee-multijob]^7 ESX setJob SUCCESS: ' .. job .. ' grade ' .. grade)
            return true
        else
            print('^1[nayzeee-multijob]^7 ERROR: xPlayer is nil for source ' .. tostring(source))
        end
    elseif fw == 'qbcore' or fw == 'qbox' then
        local player = FW.Functions.GetPlayer(source)
        if player then 
            player.Functions.SetJob(job, grade)
            print('^2[nayzeee-multijob]^7 QBCore SetJob SUCCESS')
            return true
        else
            print('^1[nayzeee-multijob]^7 ERROR: player is nil')
        end
    end
    return false
end

local function GetJobSalary(jobName, grade)
    local jobData = JobInfo[jobName]
    if jobData and jobData.grades and jobData.grades[grade] then
        return jobData.grades[grade].salary or 0
    end
    return 0
end

local function LogAction(identifier, name, action, job, details, adminId, adminName)
    MySQL.insert('INSERT INTO nayzeee_multijob_logs (identifier, player_name, action, job, details, admin_id, admin_name) VALUES (?, ?, ?, ?, ?, ?, ?)',
        { identifier, name, action, job, details, adminId, adminName })
end

-- ═══════════════════════════════════════════════════════════════════════════
-- CALLBACKS
-- ═══════════════════════════════════════════════════════════════════════════

lib.callback.register('nayzeee-multijob:getPlayerData', function(source)
    local identifier = GetIdentifier(source)
    if not identifier then return { jobs = {}, favorites = {}, stats = { jobs = {} }, schedules = {}, shifts = {} } end
    
    local jobs = MySQL.query.await('SELECT * FROM nayzeee_multijob WHERE identifier = ?', { identifier }) or {}
    local stats = MySQL.query.await('SELECT * FROM nayzeee_multijob_stats WHERE identifier = ?', { identifier }) or {}
    local schedules = MySQL.query.await('SELECT * FROM nayzeee_multijob_schedules WHERE identifier = ?', { identifier }) or {}
    local shifts = MySQL.query.await('SELECT * FROM nayzeee_multijob_shifts WHERE identifier = ? ORDER BY clock_in DESC LIMIT 10', { identifier }) or {}
    
    -- Ensure unemployed job always exists in the player's list
    local hasUnemployed = false
    for _, job in ipairs(jobs) do
        if job.job == 'unemployed' then
            hasUnemployed = true
            if IsTrue(job.removeable) then
                MySQL.query('UPDATE nayzeee_multijob SET removeable = 0 WHERE identifier = ? AND job = ?', { identifier, 'unemployed' })
                job.removeable = 0
            end
            break
        end
    end
    
    if not hasUnemployed then
        MySQL.insert('INSERT INTO nayzeee_multijob (identifier, job, grade, removeable) VALUES (?, ?, ?, 0) ON DUPLICATE KEY UPDATE removeable = 0',
            { identifier, 'unemployed', 0 })
        table.insert(jobs, { job = 'unemployed', grade = 0, removeable = 0, favorite = 0 })
    end
    
    local formattedJobs = {}
    local favorites = {}
    
    for _, job in ipairs(jobs) do
        local jobData = JobInfo[job.job]
        local gradeData = jobData and jobData.grades and jobData.grades[job.grade]
        
        table.insert(formattedJobs, {
            name = job.job,
            grade = job.grade,
            label = jobData and jobData.label or job.job,
            gradeLabel = gradeData and gradeData.label or ('Grade ' .. job.grade),
            salary = gradeData and gradeData.salary or 0,
            removeable = IsTrue(job.removeable),
            favorite = IsTrue(job.favorite),
        })
        
        if IsTrue(job.favorite) then
            favorites[job.job] = true
        end
    end
    
    local formattedStats = { jobs = {} }
    for _, stat in ipairs(stats) do
        formattedStats.jobs[stat.job] = {
            totalHours = stat.total_hours or 0,
            totalEarnings = stat.total_earnings or 0,
            sessions = stat.sessions or 0,
        }
    end
    
    local formattedSchedules = {}
    for _, s in ipairs(schedules) do
        local jobData = JobInfo[s.job]
        local days = {}
        for d in string.gmatch(s.days or '', '%d') do
            days[tonumber(d)] = true
        end
        table.insert(formattedSchedules, {
            id = s.id,
            job = s.job,
            jobLabel = jobData and jobData.label or s.job,
            grade = s.grade or 0,
            hour = s.hour or 0,
            minute = s.minute or 0,
            days = days,
            enabled = s.enabled == 1,
        })
    end
    
    local formattedShifts = {}
    for _, shift in ipairs(shifts) do
        local jobData = JobInfo[shift.job]
        table.insert(formattedShifts, {
            id = shift.id,
            job = shift.job,
            jobLabel = jobData and jobData.label or shift.job,
            clockIn = shift.clock_in,
            clockOut = shift.clock_out,
            duration = shift.duration_seconds or 0,
            earnings = shift.earnings or 0,
        })
    end
    
    return {
        jobs = formattedJobs,
        favorites = favorites,
        stats = formattedStats,
        schedules = formattedSchedules,
        shifts = formattedShifts,
    }
end)

lib.callback.register('nayzeee-multijob:getPlayerGroup', function(source)
    local fw = Shared.GetFramework()
    local FW = Shared.GetFrameworkObject()
    
    if fw == 'esx' then
        local xPlayer = FW.GetPlayerFromId(source)
        return xPlayer and xPlayer.getGroup() or 'user'
    elseif fw == 'qbcore' or fw == 'qbox' then
        if FW.Functions.HasPermission(source, 'admin') then
            return 'admin'
        end
    end
    return 'user'
end)

lib.callback.register('nayzeee-multijob:getAdminData', function(source)
    local players = {}
    local fw = Shared.GetFramework()
    local FW = Shared.GetFrameworkObject()
    
    if fw == 'esx' then
        local xPlayers = FW.GetExtendedPlayers()
        for _, xPlayer in pairs(xPlayers or {}) do
            table.insert(players, {
                id = xPlayer.source,
                identifier = xPlayer.identifier,
                name = xPlayer.getName(),
                job = xPlayer.job.name,
                grade = xPlayer.job.grade,
            })
        end
    elseif fw == 'qbcore' or fw == 'qbox' then
        local qbPlayers = FW.Functions.GetQBPlayers()
        for _, player in pairs(qbPlayers or {}) do
            table.insert(players, {
                id = player.PlayerData.source,
                identifier = player.PlayerData.citizenid,
                name = player.PlayerData.charinfo.firstname .. ' ' .. player.PlayerData.charinfo.lastname,
                job = player.PlayerData.job.name,
                grade = player.PlayerData.job.grade.level,
            })
        end
    end
    
    local logs = MySQL.query.await('SELECT * FROM nayzeee_multijob_logs ORDER BY created_at DESC LIMIT 100') or {}
    
    local analytics = {
        totalPlayers = MySQL.scalar.await('SELECT COUNT(DISTINCT identifier) FROM nayzeee_multijob') or 0,
        totalHours = MySQL.scalar.await('SELECT COALESCE(SUM(total_hours), 0) FROM nayzeee_multijob_stats') or 0,
        topJobs = MySQL.query.await('SELECT job, COUNT(*) as count FROM nayzeee_multijob GROUP BY job ORDER BY count DESC LIMIT 10') or {},
    }
    
    return {
        players = players,
        logs = logs,
        analytics = analytics,
        permissions = Config.AdminPermissions,
    }
end)

-- ═══════════════════════════════════════════════════════════════════════════
-- LEADERBOARDS (Character Names)
-- ═══════════════════════════════════════════════════════════════════════════

lib.callback.register('nayzeee-multijob:getLeaderboards', function(source)
    local leaderboards = {}
    local limit = Config.Leaderboards and Config.Leaderboards.maxEntries or 10
    local fw = Shared.GetFramework()
    
    if fw == 'esx' then
        leaderboards.total_hours = MySQL.query.await([[
            SELECT s.identifier, CONCAT(u.firstname, ' ', u.lastname) as name, SUM(s.total_hours) as value 
            FROM nayzeee_multijob_stats s
            LEFT JOIN users u ON s.identifier = u.identifier
            GROUP BY s.identifier 
            ORDER BY value DESC 
            LIMIT ?
        ]], { limit }) or {}
        
        leaderboards.total_earnings = MySQL.query.await([[
            SELECT s.identifier, CONCAT(u.firstname, ' ', u.lastname) as name, SUM(s.total_earnings) as value 
            FROM nayzeee_multijob_stats s
            LEFT JOIN users u ON s.identifier = u.identifier
            GROUP BY s.identifier 
            ORDER BY value DESC 
            LIMIT ?
        ]], { limit }) or {}
        
        leaderboards.jobs_held = MySQL.query.await([[
            SELECT m.identifier, CONCAT(u.firstname, ' ', u.lastname) as name, COUNT(DISTINCT m.job) as value 
            FROM nayzeee_multijob m
            LEFT JOIN users u ON m.identifier = u.identifier
            GROUP BY m.identifier 
            ORDER BY value DESC 
            LIMIT ?
        ]], { limit }) or {}
    elseif fw == 'qbcore' or fw == 'qbox' then
        -- QBCore uses citizenid and charinfo JSON
        local rawHours = MySQL.query.await([[
            SELECT identifier, SUM(total_hours) as value 
            FROM nayzeee_multijob_stats 
            GROUP BY identifier 
            ORDER BY value DESC 
            LIMIT ?
        ]], { limit }) or {}
        
        local rawEarnings = MySQL.query.await([[
            SELECT identifier, SUM(total_earnings) as value 
            FROM nayzeee_multijob_stats 
            GROUP BY identifier 
            ORDER BY value DESC 
            LIMIT ?
        ]], { limit }) or {}
        
        local rawJobs = MySQL.query.await([[
            SELECT identifier, COUNT(DISTINCT job) as value 
            FROM nayzeee_multijob 
            GROUP BY identifier 
            ORDER BY value DESC 
            LIMIT ?
        ]], { limit }) or {}
        
        -- Resolve names for QBCore
        for _, entry in ipairs(rawHours) do
            entry.name = GetCharacterName(entry.identifier)
        end
        for _, entry in ipairs(rawEarnings) do
            entry.name = GetCharacterName(entry.identifier)
        end
        for _, entry in ipairs(rawJobs) do
            entry.name = GetCharacterName(entry.identifier)
        end
        
        leaderboards.total_hours = rawHours
        leaderboards.total_earnings = rawEarnings
        leaderboards.jobs_held = rawJobs
    else
        leaderboards.total_hours = {}
        leaderboards.total_earnings = {}
        leaderboards.jobs_held = {}
    end
    
    return leaderboards
end)

lib.callback.register('nayzeee-multijob:adminGetPlayer', function(source, targetId)
    local identifier = GetIdentifier(targetId)
    if not identifier then return { jobs = {}, stats = {} } end
    
    local jobs = MySQL.query.await('SELECT * FROM nayzeee_multijob WHERE identifier = ?', { identifier }) or {}
    local stats = MySQL.query.await('SELECT * FROM nayzeee_multijob_stats WHERE identifier = ?', { identifier }) or {}
    
    return { jobs = jobs, stats = stats }
end)

-- ═══════════════════════════════════════════════════════════════════════════
-- JOB SWITCH EVENT
-- ═══════════════════════════════════════════════════════════════════════════

RegisterNetEvent('nayzeee-multijob:switchJob', function(jobName, grade)
    local source = source
    local identifier = GetIdentifier(source)
    if not identifier then 
        print('^1[nayzeee-multijob]^7 ERROR: No identifier for source ' .. tostring(source))
        return 
    end
    
    print('^3[nayzeee-multijob]^7 switchJob received: job=' .. tostring(jobName) .. ', grade=' .. tostring(grade))
    
    if not JobInfo[jobName] then
        print('^1[nayzeee-multijob]^7 ERROR: Job "' .. tostring(jobName) .. '" does not exist in framework!')
        Notify(source, { title = 'Error', message = 'Job does not exist: ' .. tostring(jobName), type = 'error' })
        return
    end
    
    local hasJob = MySQL.scalar.await('SELECT 1 FROM nayzeee_multijob WHERE identifier = ? AND job = ?', { identifier, jobName })
    
    local isDefault = false
    for _, dJob in ipairs(Config.NonRemovableJobs or {}) do
        if dJob == jobName then isDefault = true break end
    end
    
    if jobName == 'unemployed' or jobName == 'offduty' then
        isDefault = true
    end
    
    if not hasJob and not isDefault then
        print('^1[nayzeee-multijob]^7 Player does not have job "' .. jobName .. '" in their list')
        Notify(source, { title = 'Error', message = 'You do not have this job', type = 'error' })
        return
    end
    
    local storedGrade = grade or 0
    if hasJob then
        local jobData = MySQL.query.await('SELECT grade FROM nayzeee_multijob WHERE identifier = ? AND job = ?', { identifier, jobName })
        if jobData and jobData[1] then
            storedGrade = jobData[1].grade or grade or 0
        end
    end
    
    local success = SetPlayerJob(source, jobName, storedGrade)
    
    if success then
        local jobLabel = JobInfo[jobName] and JobInfo[jobName].label or jobName
        TriggerClientEvent('nayzeee-multijob:jobSwitched', source, jobName, jobLabel)
        LogAction(identifier, GetPlayerNameServer(source), 'job_switch', jobName, 'Grade: ' .. storedGrade, nil, nil)
        print('^2[nayzeee-multijob]^7 Job switched successfully to ' .. jobName .. ' grade ' .. storedGrade)
    else
        Notify(source, { title = 'Error', message = 'Failed to switch job', type = 'error' })
    end
end)

RegisterNetEvent('nayzeee-multijob:checkNewJob', function(oldJob, newJob, newGrade)
    local source = source
    local identifier = GetIdentifier(source)
    if not identifier then return end
    
    if Shared.IsBlacklisted(newJob) then return end
    
    local exists = MySQL.scalar.await('SELECT 1 FROM nayzeee_multijob WHERE identifier = ? AND job = ?', { identifier, newJob })
    if exists then
        MySQL.update('UPDATE nayzeee_multijob SET grade = ? WHERE identifier = ? AND job = ?', { newGrade, identifier, newJob })
        return
    end
    
    -- Count jobs EXCLUDING unemployed — unemployed is always free
    local jobCount = MySQL.scalar.await("SELECT COUNT(*) FROM nayzeee_multijob WHERE identifier = ? AND job != 'unemployed'", { identifier }) or 0
    if jobCount >= (Config.MaxJobs or 5) then return end
    
    MySQL.insert('INSERT INTO nayzeee_multijob (identifier, job, grade, removeable) VALUES (?, ?, ?, 1)', { identifier, newJob, newGrade })
    TriggerClientEvent('nayzeee-multijob:jobAdded', source)
    LogAction(identifier, GetPlayerNameServer(source), 'job_added', newJob, 'Auto-added', nil, nil)
end)

RegisterNetEvent('nayzeee-multijob:removeJob', function(jobName)
    local source = source
    local identifier = GetIdentifier(source)
    if not identifier then return end
    
    if Shared.IsNonRemovable(jobName) then return end
    
    MySQL.query('DELETE FROM nayzeee_multijob WHERE identifier = ? AND job = ?', { identifier, jobName })
    TriggerClientEvent('nayzeee-multijob:jobRemoved', source)
    LogAction(identifier, GetPlayerNameServer(source), 'job_removed', jobName, 'Self-removed', nil, nil)
end)

RegisterNetEvent('nayzeee-multijob:quitJob', function(jobName)
    local source = source
    local identifier = GetIdentifier(source)
    if not identifier then return end
    
    if jobName == 'unemployed' then return end
    
    local success = SetPlayerJob(source, Config.DefaultJob.name, Config.DefaultJob.grade)
    
    if success then
        MySQL.query('DELETE FROM nayzeee_multijob WHERE identifier = ? AND job = ?', { identifier, jobName })
        
        TriggerClientEvent('nayzeee-multijob:jobSwitched', source, Config.DefaultJob.name, 'Unemployed')
        TriggerClientEvent('nayzeee-multijob:jobRemoved', source)
        LogAction(identifier, GetPlayerNameServer(source), 'quit_job', jobName, 'Voluntarily quit', nil, nil)
        
        print('^2[nayzeee-multijob]^7 Player ' .. GetPlayerNameServer(source) .. ' quit job: ' .. jobName)
    else
        Notify(source, { title = 'Error', message = 'Failed to quit job', type = 'error' })
    end
end)

-- ═══════════════════════════════════════════════════════════════════════════
-- DUTY EVENTS WITH EARNINGS TRACKING
-- ═══════════════════════════════════════════════════════════════════════════

RegisterNetEvent('nayzeee-multijob:clockIn', function(jobName)
    local source = source
    local identifier = GetIdentifier(source)
    if not identifier then return end
    
    DutySessions[source] = {
        job = jobName,
        startTime = os.time(),
        identifier = identifier,
        shiftId = nil,
        paychecks = 0
    }
    
    local shiftId = MySQL.insert.await('INSERT INTO nayzeee_multijob_shifts (identifier, job, clock_in) VALUES (?, ?, NOW())', { identifier, jobName })
    DutySessions[source].shiftId = shiftId
    
    MySQL.query('INSERT INTO nayzeee_multijob_stats (identifier, job, sessions, last_clocked) VALUES (?, ?, 1, NOW()) ON DUPLICATE KEY UPDATE sessions = sessions + 1, last_clocked = NOW()', { identifier, jobName })
    
    LogAction(identifier, GetPlayerNameServer(source), 'clock_in', jobName, nil, nil, nil)
    print('^2[nayzeee-multijob]^7 Player ' .. GetPlayerNameServer(source) .. ' clocked in to ' .. jobName)
end)

RegisterNetEvent('nayzeee-multijob:clockOut', function(jobName, dutySeconds)
    local source = source
    local identifier = GetIdentifier(source)
    if not identifier then return end
    
    local session = DutySessions[source]
    local hours = (dutySeconds or 0) / 3600
    
    local fw = Shared.GetFramework()
    local FW = Shared.GetFrameworkObject()
    local currentGrade = 0
    local salary = 0
    
    if fw == 'esx' then
        local xPlayer = FW.GetPlayerFromId(source)
        if xPlayer then
            currentGrade = xPlayer.job.grade or 0
            salary = xPlayer.job.grade_salary or 0
        end
    elseif fw == 'qbcore' or fw == 'qbox' then
        local player = FW.Functions.GetPlayer(source)
        if player then
            currentGrade = player.PlayerData.job.grade.level or 0
            salary = player.PlayerData.job.payment or 0
        end
    end
    
    local earnings = math.floor(salary * hours)
    
    print('^3[nayzeee-multijob]^7 Clock out: job=' .. jobName .. ', hours=' .. string.format('%.2f', hours) .. ', salary=' .. salary .. ', earnings=' .. earnings)
    
    if session and session.shiftId then
        MySQL.query('UPDATE nayzeee_multijob_shifts SET clock_out = NOW(), duration_seconds = ?, earnings = ? WHERE id = ?', 
            { math.floor(dutySeconds or 0), earnings, session.shiftId })
    end
    
    MySQL.query('INSERT INTO nayzeee_multijob_stats (identifier, job, total_hours, total_earnings, sessions) VALUES (?, ?, ?, ?, 1) ON DUPLICATE KEY UPDATE total_hours = total_hours + ?, total_earnings = total_earnings + ?', 
        { identifier, jobName, hours, earnings, hours, earnings })
    
    DutySessions[source] = nil
    
    TriggerClientEvent('nayzeee-multijob:shiftEnded', source, {
        job = jobName,
        duration = math.floor(dutySeconds or 0),
        earnings = earnings
    })
    
    LogAction(identifier, GetPlayerNameServer(source), 'clock_out', jobName, string.format('%.2f hours, $%d earned', hours, earnings), nil, nil)
    print('^2[nayzeee-multijob]^7 Player ' .. GetPlayerNameServer(source) .. ' clocked out: ' .. string.format('%.2f', hours) .. ' hours, $' .. earnings .. ' earned')
end)

-- Track ESX paycheck for accurate earnings
AddEventHandler('nayzeee-multijob:trackPaycheck', function(playerSource, amount, jobName)
    local identifier = GetIdentifier(playerSource)
    local session = DutySessions[playerSource]
    
    if identifier and amount and jobName then
        MySQL.query('INSERT INTO nayzeee_multijob_stats (identifier, job, total_earnings, total_hours, sessions) VALUES (?, ?, ?, 0, 0) ON DUPLICATE KEY UPDATE total_earnings = total_earnings + ?', 
            { identifier, jobName, amount, amount })
        
        if session and session.shiftId then
            session.paychecks = (session.paychecks or 0) + 1
            MySQL.query('UPDATE nayzeee_multijob_shifts SET earnings = earnings + ? WHERE id = ?', 
                { amount, session.shiftId })
        end
        
        print('^2[nayzeee-multijob]^7 Tracked paycheck: $' .. tostring(amount) .. ' for player ' .. tostring(playerSource) .. ' (' .. tostring(jobName) .. ')')
    end
end)

RegisterNetEvent('nayzeee-multijob:saveDutyTime', function(jobName, dutySeconds)
    local source = source
    local identifier = GetIdentifier(source)
    if not identifier then return end
    
    MySQL.query('UPDATE nayzeee_multijob_stats SET last_clocked = NOW() WHERE identifier = ? AND job = ?', { identifier, jobName })
end)

-- ═══════════════════════════════════════════════════════════════════════════
-- SCHEDULE EVENTS
-- ═══════════════════════════════════════════════════════════════════════════

RegisterNetEvent('nayzeee-multijob:saveSchedule', function(data)
    local source = source
    local identifier = GetIdentifier(source)
    if not identifier or not data then return end
    
    local daysStr = table.concat(data.days or {}, '')
    
    if data.id then
        MySQL.query('UPDATE nayzeee_multijob_schedules SET job = ?, grade = ?, hour = ?, minute = ?, days = ?, enabled = ? WHERE id = ? AND identifier = ?',
            { data.job, data.grade or 0, data.hour or 0, data.minute or 0, daysStr, data.enabled and 1 or 0, data.id, identifier })
    else
        MySQL.insert('INSERT INTO nayzeee_multijob_schedules (identifier, job, grade, hour, minute, days, enabled) VALUES (?, ?, ?, ?, ?, ?, ?)',
            { identifier, data.job, data.grade or 0, data.hour or 0, data.minute or 0, daysStr, data.enabled and 1 or 0 })
    end
end)

RegisterNetEvent('nayzeee-multijob:deleteSchedule', function(scheduleId)
    local source = source
    local identifier = GetIdentifier(source)
    if not identifier then return end
    
    MySQL.query('DELETE FROM nayzeee_multijob_schedules WHERE id = ? AND identifier = ?', { scheduleId, identifier })
end)

-- ═══════════════════════════════════════════════════════════════════════════
-- ADMIN EVENTS
-- ═══════════════════════════════════════════════════════════════════════════

RegisterNetEvent('nayzeee-multijob:adminAddJob', function(targetId, jobName, grade)
    local source = source
    local adminId = GetIdentifier(source)
    local targetIdentifier = GetIdentifier(targetId)
    if not targetIdentifier then return end
    
    MySQL.query('INSERT INTO nayzeee_multijob (identifier, job, grade, removeable) VALUES (?, ?, ?, 1) ON DUPLICATE KEY UPDATE grade = ?',
        { targetIdentifier, jobName, grade or 0, grade or 0 })
    
    LogAction(targetIdentifier, GetPlayerNameServer(targetId), 'admin_add_job', jobName, 'Grade: ' .. (grade or 0), adminId, GetPlayerNameServer(source))
end)

RegisterNetEvent('nayzeee-multijob:adminRemoveJob', function(targetId, jobName)
    local source = source
    local adminId = GetIdentifier(source)
    local targetIdentifier = GetIdentifier(targetId)
    if not targetIdentifier then return end
    
    MySQL.query('DELETE FROM nayzeee_multijob WHERE identifier = ? AND job = ?', { targetIdentifier, jobName })
    LogAction(targetIdentifier, GetPlayerNameServer(targetId), 'admin_remove_job', jobName, nil, adminId, GetPlayerNameServer(source))
end)

RegisterNetEvent('nayzeee-multijob:adminBulkAction', function(action, playerIds, jobName, grade)
    local source = source
    local adminId = GetIdentifier(source)
    
    for _, targetId in ipairs(playerIds or {}) do
        local targetIdentifier = GetIdentifier(targetId)
        if targetIdentifier then
            if action == 'add' then
                MySQL.query('INSERT INTO nayzeee_multijob (identifier, job, grade, removeable) VALUES (?, ?, ?, 1) ON DUPLICATE KEY UPDATE grade = ?',
                    { targetIdentifier, jobName, grade or 0, grade or 0 })
            elseif action == 'remove' then
                MySQL.query('DELETE FROM nayzeee_multijob WHERE identifier = ? AND job = ?', { targetIdentifier, jobName })
            elseif action == 'setjob' then
                SetPlayerJob(targetId, jobName, grade or 0)
            end
            LogAction(targetIdentifier, GetPlayerNameServer(targetId), 'admin_bulk_' .. action, jobName, nil, adminId, GetPlayerNameServer(source))
        end
    end
end)

-- ═══════════════════════════════════════════════════════════════════════════
-- PLAYER DISCONNECT
-- ═══════════════════════════════════════════════════════════════════════════

AddEventHandler('playerDropped', function()
    local source = source
    local session = DutySessions[source]
    
    if session then
        local dutySeconds = os.time() - session.startTime
        local hours = dutySeconds / 3600
        local salary = GetJobSalary(session.job, 0)
        local earnings = math.floor(salary * hours)
        
        if session.shiftId then
            MySQL.query('UPDATE nayzeee_multijob_shifts SET clock_out = NOW(), duration_seconds = ?, earnings = ? WHERE id = ?', 
                { dutySeconds, earnings, session.shiftId })
        end
        
        MySQL.query('UPDATE nayzeee_multijob_stats SET total_hours = total_hours + ?, total_earnings = total_earnings + ? WHERE identifier = ? AND job = ?', 
            { hours, earnings, session.identifier, session.job })
        
        LogAction(session.identifier, 'Disconnected', 'clock_out', session.job, string.format('%.2f hours (disconnect)', hours), nil, nil)
        
        DutySessions[source] = nil
    end
end)

-- ═══════════════════════════════════════════════════════════════════════════
-- EXPORTS
-- ═══════════════════════════════════════════════════════════════════════════

exports('GetPlayerJobs', function(source)
    local identifier = GetIdentifier(source)
    if not identifier then return {} end
    return MySQL.query.await('SELECT * FROM nayzeee_multijob WHERE identifier = ?', { identifier }) or {}
end)

exports('AddPlayerJob', function(source, jobName, grade)
    local identifier = GetIdentifier(source)
    if not identifier then return false end
    MySQL.insert('INSERT INTO nayzeee_multijob (identifier, job, grade, removeable) VALUES (?, ?, ?, 1) ON DUPLICATE KEY UPDATE grade = ?',
        { identifier, jobName, grade or 0, grade or 0 })
    return true
end)

exports('RemovePlayerJob', function(source, jobName)
    local identifier = GetIdentifier(source)
    if not identifier then return false end
    MySQL.query('DELETE FROM nayzeee_multijob WHERE identifier = ? AND job = ?', { identifier, jobName })
    return true
end)

exports('GetJobHours', function(source, jobName)
    local identifier = GetIdentifier(source)
    if not identifier then return 0 end
    return MySQL.scalar.await('SELECT total_hours FROM nayzeee_multijob_stats WHERE identifier = ? AND job = ?', { identifier, jobName }) or 0
end)

exports('GetJobEarnings', function(source, jobName)
    local identifier = GetIdentifier(source)
    if not identifier then return 0 end
    return MySQL.scalar.await('SELECT total_earnings FROM nayzeee_multijob_stats WHERE identifier = ? AND job = ?', { identifier, jobName }) or 0
end)

exports('TrackPaycheck', function(source, amount)
    TriggerEvent('nayzeee-multijob:trackPaycheck', amount)
end)

exports('IsPlayerOnDuty', function(source)
    return DutySessions[source] ~= nil
end)
