# 💼 NAYZEEE MultiJob

Advanced Multi-Job Management System for FiveM with comprehensive tracking, scheduling, and admin features.

![Version](https://img.shields.io/badge/version-1.0.0-08afa2)
![Framework](https://img.shields.io/badge/framework-ESX%20%7C%20QBCore%20%7C%20QBox-blue)

---

## ✨ Features

### Core Features
- **Job Categories & Organization** - Jobs grouped by Emergency, Business, Criminal, Civilian with icons
- **Favorite/Pin Jobs** - Quick access to most-used jobs
- **Job Search & Filter** - Instant search in large job lists

### Duty & Time Tracking
- **Duty Timer** - Live shift duration display
- **Shift History/Logs** - Past shifts with timestamps
- **Auto Clock-Out** - Automatic logout after inactivity

### Statistics Dashboard
- **Earnings History** - Money made per job over time
- **Weekly/Monthly Reports** - Detailed breakdowns

### Job Progression
- **Job Requirements** - Show unlock requirements
- **Job Perks** - Unlock benefits at milestones

### Admin Panel
- **Full Player Management** - View/edit any player's jobs
- **Bulk Operations** - Mass assign/remove jobs
- **Activity Logs** - Job switch tracking
- **Job Analytics** - Server-wide statistics

### Smart Features
- **Job Cooldowns** - Prevent rapid switching abuse
- **Schedule System** - Auto-switch at set times

---

## 📦 Dependencies

| Dependency | Required |
|------------|----------|
| [ox_lib](https://github.com/overextended/ox_lib) | ✅ |
| [oxmysql](https://github.com/overextended/oxmysql) | ✅ |
| ESX / QBCore / QBox | ✅ |

---

## 🔧 Installation

1. Download and extract to your resources folder
2. Add `ensure nayzeee-multijob` to your server.cfg
3. Database tables are created automatically on first start
4. Configure `config.lua` to your preferences
5. Restart your server

---

## ⚙️ Configuration

### General Settings
```lua
Config.MaxJobs = 5          -- Maximum secondary jobs
Config.Command = 'jobs'     -- Command to open menu
Config.AdminCommand = 'jobadmin'  -- Admin panel command
Config.Keybind = 'F6'       -- Keybind (false to disable)
```

### Job Categories
```lua
Config.Categories = {
    emergency = {
        label = 'Emergency Services',
        icon = 'fa-solid fa-truck-medical',
        color = '#ef4444',
        jobs = { 'police', 'ambulance', 'firefighter' }
    },
    -- Add more categories...
}
```

### Cooldowns
```lua
Config.Cooldowns = {
    enabled = true,
    globalCooldown = 300,  -- 5 minutes
    jobCooldowns = {
        police = 600,      -- 10 minutes for police
    },
    exempt = { 'unemployed', 'offduty' }
}
```

### Job Perks
```lua
Config.Perks.jobPerks = {
    police = {
        { hours = 10, perk = 'radio_access', label = 'Police Radio Access' },
        { hours = 50, perk = 'vehicle_discount', label = '10% Vehicle Discount', value = 0.10 },
    },
}
```

---

## 📋 Commands

| Command | Description |
|---------|-------------|
| `/jobs` | Open the job menu |
| `/jobadmin` | Open admin panel (requires permission) |

---

## 🔌 Exports

### Client Exports
```lua
-- Get all player jobs
exports['nayzeee-multijob']:GetPlayerJobs()

-- Get current job
local job, grade = exports['nayzeee-multijob']:GetCurrentJob()

-- Check if on duty
exports['nayzeee-multijob']:IsOnDuty()

-- Get duty time in seconds
exports['nayzeee-multijob']:GetDutyTime()

-- Check if player has a perk
exports['nayzeee-multijob']:HasPerk('radio_access')
```

### Server Exports
```lua
-- Get player's jobs
exports['nayzeee-multijob']:GetPlayerJobs(source)

-- Add job to player
exports['nayzeee-multijob']:AddPlayerJob(source, 'mechanic', 2)

-- Remove job from player
exports['nayzeee-multijob']:RemovePlayerJob(source, 'mechanic')

-- Check if player has perk
exports['nayzeee-multijob']:HasPerk(source, 'vehicle_discount')

-- Get player's hours for a job
exports['nayzeee-multijob']:GetJobHours(source, 'police')
```

---

## 📁 Folder Name

The folder **must** be named exactly `nayzeee-multijob`.

If it is renamed, `lock.lua` prints the reason to console and stops the
resource before anything else loads — it will not run half-working. The name
is baked into the exports, the `nayzeee-multijob:*` events and
`install/REPLACE_paycheck.lua`, so a rename would break duty checks, paycheck
gating and notifications silently.

`lock.lua` is encrypted with the rest of the resource, not in `escrow_ignore`.

---

## 🎨 UI Theme

The whole menu is driven off `Config.UI`. Change the accent and every teal
element follows it — nav highlight, buttons, tags, meters, the brand mark, the
glow on the duty ring.

```lua
Config.UI = {
    accent     = '#08afa2',  -- one value themes the entire menu
    accentHi   = nil,        -- nil = derived from accent
    accentLo   = nil,
    danger     = '#e5484d',  -- Close pill, deletes, warnings
    background = '#000000',  -- surfaces step up from this automatically
    font       = 'Lexend',
    title      = 'Job Center',
    subtitle   = 'Employment Services',
    grain      = true,       -- film grain over the window
    watermark  = true,       -- faded shape bottom-right

    width      = 860,        -- window width in px
    height     = 470,        -- content area height in px
    sidebar    = 190,        -- left nav rail width in px
}
```

The menu is a compact in-game panel by default, not a full-screen takeover.
`width` / `height` / `sidebar` resize it without touching the CSS — the layout
is built on those three tokens.

Only `accent` is needed. Highlights, gradients, washes and borders are derived
from it at runtime, and button text flips between black and white depending on
how light the accent is, so nothing goes unreadable.

Changing `font` also means swapping the Google Fonts link in
`html/index.html` for the family you want.

---

## 🔔 Notifications & Phone Support

One switch decides what the player sees. A message is never shown twice unless
you ask for it.

```lua
Config.Notifications.output = 'notify'
```

| Value | Result |
|---|---|
| `notify` | on-screen notification only — no phone |
| `phone` | phone notification only — no on-screen popup |
| `both` | both at once (optional) |

If `output` is `phone` but no supported phone is running, messages fall back to
the on-screen notify so nothing is silently lost, and the console says so once
on startup.

### Which notify resource

```lua
Config.Notifications.system = 'auto'
```

`auto` · `nayzeee` · `ox_lib` · `okok` · `codem` · `mythic` · `brutal` ·
`t-notify` · `qb` · `esx` · `esx_advanced` · `chat` · `native`

`native` uses the GTA feed and needs no dependency at all.

### Which phone

```lua
Config.Notifications.phone = {
    resource = 'auto',
    app      = 'Wallet',
}
```

`auto` · `lb-phone` · `qs-smartphone` · `qs-smartphone-pro` · `gksphone` ·
`roadphone` · `yflip-phone` · `high-phone` · `npwd` · `qb-phone`

### Adding your own

`notify/adapters.lua` is open (escrow_ignore). Add one function and point the
config at it:

```lua
-- client
NayNotify.Systems['myNotify'] = function(data)
    exports['my-notify']:Send(data.title, data.message, data.type, data.duration)
end

-- server (phone)
NayNotify.Phones['my-phone'] = function(src, data)
    exports['my-phone']:Notify(src, data.app, data.title, data.message)
end
```

Phone resources change their export signatures between versions. If a phone
doesn't fire on your build, fix that one function — nothing else changes.

### Notification exports

```lua
exports['nayzeee-multijob']:Notify(src, { title = 'Job', message = 'Hello', type = 'success' })
exports['nayzeee-multijob']:NotifyPlayer(src, 'Job', 'Hello', 'success')
exports['nayzeee-multijob']:GetActivePhone()       -- detected phone name, or nil
exports['nayzeee-multijob']:RefreshNotifyTargets() -- re-detect after restarting a phone
```

---

## 💵 ESX Paycheck Integration

`install/REPLACE_paycheck.lua` replaces `es_extended/server/paycheck.lua`.
Players only get paid while clocked in through the job menu; unemployed players
still receive welfare normally.

Options at the top of that file:

```lua
local NAYZEEE = {
    requireClockIn    = true,          -- pay only while clocked in
    notifySkipped     = true,          -- tell the player why they weren't paid
    useMultijobNotify = true,          -- use Config.Notifications (phones + notify)
    fallback          = 'esx_advanced',-- used if multijob is stopped
}
```

Paycheck amounts are written back into `nayzeee_multijob_stats` so the earnings
leaderboard and shift history stay accurate.

---

## 🎨 Customization

The UI uses the NAYZEEE design system:
- **Primary Color:** `#08afa2` (Teal)
- **Background:** `#0f1419` (Dark)
- **Font:** Lexend

Modify `html/style.css` to customize colors and styling.

---

## 🔧 Troubleshooting

| Issue | Solution |
|-------|----------|
| Menu won't open | Check if ox_lib is started before this resource |
| Jobs not saving | Verify oxmysql is connected and running |
| Admin panel access denied | Add your group to `Config.AdminGroups` |
| Cooldown not working | Check `Config.Cooldowns.enabled` is true |

---

## 📞 Support

- Discord: [discord.gg/nayzeeedev](https://discord.gg/nayzeeedev)
- Documentation: Coming soon

---

## 📄 License

© 2024 NAYZEEE Development. All rights reserved.
